import React from 'react';
import { MacHero } from '../components/mac/MacHero';

export default function MacServices() {
  return (
    <div className="min-h-screen">
      <MacHero />
    </div>
  );
}